# -*- coding: utf-8 -*-
"""
Created on Sat Jan 27 03:02:16 2024

@author: DHANUNJAY
"""
import fitz  # PyMuPDF
import docx
from docx.shared import Inches
import os
from docx.enum.text import WD_ALIGN_PARAGRAPH
from PIL import Image, ImageFilter, ImageEnhance
import cv2
import numpy as np

Image.MAX_IMAGE_PIXELS = None

def convert_all_pdfs_to_images_docx(input_folder, output_folder):
    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Process all PDF files in the input folder
    for file_name in os.listdir(input_folder):
        if file_name.endswith(".pdf"):
            input_pdf = os.path.join(input_folder, file_name)
            output_docx = os.path.join(output_folder, f"{os.path.splitext(file_name)[0]}.docx")
            convert_pdf_to_images_docx(input_pdf, output_docx)

def convert_pdf_to_images_docx(input_pdf, output_docx):
    with fitz.open(input_pdf) as doc:
        new_document = docx.Document()

        for page_num in range(len(doc)):
            page = doc[page_num]

            # Increase DPI for better image quality
            pix = page.get_pixmap(matrix=fitz.Matrix(50, 50), dpi=1800)
            pix.save(f"temp_page_{page_num}.png")

            # Enhance image quality using Pillow (PIL)
            enhanced_image = enhance_image_quality(f"temp_page_{page_num}.png")
            enhanced_image.save(f"temp_page_{page_num}.png")

            # Insert the image into the new document
            paragraph = new_document.add_paragraph()
            run = paragraph.add_run()
            run.add_picture(f"temp_page_{page_num}.png", width=Inches(6))  # Adjust width as needed
            run.alignment = WD_ALIGN_PARAGRAPH.CENTER  # Center the image

            os.remove(f"temp_page_{page_num}.png")  # Remove temporary image

        new_document.save(output_docx)

'''def enhance_image_quality(image_path):
    image = Image.open(image_path)
    
    # enhancer = ImageEnhance.Contrast(image)
    # image = enhancer.enhance(2.0)  # Adjust the factor as needed
    curr_sharp = ImageEnhance.Sharpness(image) 
    new_sharp = 8.3
  
    # Sharpness enhanced by a factor of 8.3 
    image = curr_sharp.enhance(new_sharp) 


    # Additional filters for enhancement
    enhanced_image = image.filter(ImageFilter.SHARPEN)
    enhanced_image = enhanced_image.filter(ImageFilter.SMOOTH_MORE)

    return enhanced_image'''


'''def enhance_image_quality(image_path):
    # Read the image using OpenCV
    image = cv2.imread(image_path)

    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (1, 1), 0)  # Reduce kernel size for less blurring

    # Apply adaptive thresholding to enhance contrast
    _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Perform morphological operations to remove noise and improve character quality
    kernel = np.ones((1, 1), np.uint8)  # Decrease kernel size for less thickening
    closing = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=1)  # Decrease iterations for less effect
    dilation = cv2.dilate(closing, kernel, iterations=1)  # Dilation operation

    # Invert the image back to get characters in white
    enhanced_image = cv2.bitwise_not(dilation)

    # Convert the NumPy array back to a PIL Image object
    enhanced_image_pil = Image.fromarray(enhanced_image)

    return enhanced_image_pil'''

'''def enhance_image_quality(image_path):
    # Read the image using OpenCV
    image = cv2.imread(image_path)

    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply adaptive histogram equalization to enhance contrast
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced_gray = clahe.apply(gray)

    # Apply Unsharp Masking to enhance sharpness
    blurred = cv2.GaussianBlur(enhanced_gray, (0, 0), 3)
    sharpened = cv2.addWeighted(enhanced_gray, 1.5, blurred, -0.5, 0)

    # Convert the enhanced grayscale image to RGB
    enhanced_image = cv2.cvtColor(sharpened, cv2.COLOR_GRAY2RGB)

    # Convert the NumPy array back to a PIL Image object
    enhanced_image_pil = Image.fromarray(enhanced_image)

    return enhanced_image_pil'''


def enhance_image_quality(image_path):
    # Read the image using OpenCV
    image = cv2.imread(image_path)

    # Apply bilateral filtering for denoising while preserving edges
    denoised = cv2.bilateralFilter(image, 9, 75, 75)

    # Convert the denoised image to grayscale
    gray = cv2.cvtColor(denoised, cv2.COLOR_BGR2GRAY)

    # Apply adaptive histogram equalization to enhance contrast
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced_gray = clahe.apply(gray)

    # Apply Unsharp Masking to enhance sharpness
    blurred = cv2.GaussianBlur(enhanced_gray, (0, 0), 3)
    sharpened = cv2.addWeighted(enhanced_gray, 1.5, blurred, -0.5, 0)

    # Convert the enhanced grayscale image to RGB
    enhanced_image = cv2.cvtColor(sharpened, cv2.COLOR_GRAY2RGB)

    # Resize the image to a larger size for better quality
    enhanced_image = cv2.resize(enhanced_image, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)

    # Convert the NumPy array back to a PIL Image object
    enhanced_image_pil = Image.fromarray(enhanced_image)

    return enhanced_image_pil




# Example usage
input_folder = "C:/Users/DHANUNJAY/Desktop/Maps/TaggedFiles"
output_folder = "C:/Users/DHANUNJAY/Desktop/Maps/Input"
convert_all_pdfs_to_images_docx(input_folder, output_folder)
