# -*- coding: utf-8 -*-
"""
Created on Sat Jan 20 00:44:51 2024

@author: Rajesh Gade
"""


import os
import logging
from pathlib import Path
import shutil

from adobe.pdfservices.operation.auth.credentials import Credentials
from adobe.pdfservices.operation.exception.exceptions import ServiceApiException, ServiceUsageException, SdkException
from adobe.pdfservices.operation.execution_context import ExecutionContext
from adobe.pdfservices.operation.io.file_ref import FileRef

from adobe.pdfservices.operation.internal.api.dto.request.autotagpdf.autotag_pdf_output import AutotagPDFOutput
from adobe.pdfservices.operation.pdfops.autotag_pdf_operation import AutotagPDFOperation

logging.basicConfig(level=os.environ.get('LOGLEVEL', 'INFO'))

def movefiles(source_folder, destination_folder):
    # Specify source and destination folders
    # source_folder = "C:/Users/DHANUNJAY/Downloads/PDFServicesSDK-Python (Extract, Auto-Tag)Samples/adobe-dc-pdf-services-sdk-python/src/PdfFiles/Output"
    # destination_folder = "C:/Users/DHANUNJAY/Downloads/PDFServicesSDK-Python (Extract, Auto-Tag)Samples/adobe-dc-pdf-services-sdk-python/src/PdfFiles/OutputOld"
    
    # Iterate through files in the source folder
    for filename in os.listdir(source_folder):
        source_file = os.path.join(source_folder, filename)
        destination_file = os.path.join(destination_folder, filename)
        
        # Move the file using shutil.move()
        shutil.move(source_file, destination_file)
        
        print("Old files moved to backup folder successfully!")


try:
    source_folder = "C:/Users/DHANUNJAY/Downloads/PDFServicesSDK-Python (Extract, Auto-Tag)Samples/adobe-dc-pdf-services-sdk-python/src/PdfFiles/Output"
    destination_folder = "C:/Users/DHANUNJAY/Downloads/PDFServicesSDK-Python (Extract, Auto-Tag)Samples/adobe-dc-pdf-services-sdk-python/src/PdfFiles/OutputOld"
    source_folder2 = "C:/Users/DHANUNJAY/Downloads/PDFServicesSDK-Python (Extract, Auto-Tag)Samples/adobe-dc-pdf-services-sdk-python/src/PdfFiles/Input"
    destination_folder2 = "C:/Users/DHANUNJAY/Downloads/PDFServicesSDK-Python (Extract, Auto-Tag)Samples/adobe-dc-pdf-services-sdk-python/src/PdfFiles/InputOld"

    # movefiles(source_folder, destination_folder)
    # movefiles(source_folder2, destination_folder2)
    
    PDF_SERVICES_CLIENT_ID = '12a5920a3d124dffbc996a939f073f14'
    PDF_SERVICES_CLIENT_SECRET = 'p8e-F9GBXGoO2OqXAXQmLshrouGrdyYTVLR4'

    # Initial setup, create credentials instance.
    credentials = Credentials.service_principal_credentials_builder(). \
        with_client_id(PDF_SERVICES_CLIENT_ID). \
        with_client_secret(PDF_SERVICES_CLIENT_SECRET). \
        build()

    # Create an ExecutionContext using credentials.
    execution_context = ExecutionContext.create(credentials)

    # Set input and output paths
    input_folder = "C:/Users/DHANUNJAY/Desktop/Maps/TabFiles/"
    output_folder = "C:/Users/DHANUNJAY/Desktop/Maps/TaggedFiles/"

    # Iterate over files in the input folder
    for input_file_name in os.listdir(input_folder):
        input_file_path = os.path.join(input_folder, input_file_name)

        # Create a new AutotagPDFOperation instance for each file
        autotag_pdf_operation = AutotagPDFOperation.create_new()

        # Set operation input from a source file.
        source = FileRef.create_from_local_file(input_file_path)
        autotag_pdf_operation.set_input(source)

        # Execute the operation.
        autotag_pdf_output: AutotagPDFOutput = autotag_pdf_operation.execute(execution_context)

        # Save the result to the specified location in the output folder.
        output_file_path = os.path.join(output_folder, f'{input_file_name}-tagged.pdf')
        autotag_pdf_output.get_tagged_pdf().save_as(output_file_path)

except (ServiceApiException, ServiceUsageException, SdkException) as e:
    logging.exception(f'Exception encountered while executing operation: {e}')
