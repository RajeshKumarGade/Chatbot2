
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 27 03:02:16 2024

@author: DHANUNJAY
"""
import time
import pyautogui
import subprocess
import win32com.client
import os

def get_number_of_pages(word_file_path):
    # Create a new Word application
    word_app = win32com.client.Dispatch("Word.Application")

    # Open the Word document
    doc = word_app.Documents.Open(word_file_path)

    # Get the number of pages
    num_pages = doc.ComputeStatistics(2)  # 2 corresponds to the total number of pages

    # Close the Word document
    doc.Close()

    # Quit the Word application
    word_app.Quit()
    # print('num pages : ',num_pages)

    return num_pages

def open_word_document(file_path):
    subprocess.Popen(["start", "winword", file_path], shell=True)
    
    
def zoom_to_100_percent():
    # Press 'Alt + W + Q' to open the 'View' tab and select 'Zoom to 100%'
    pyautogui.hotkey('alt', 'w', 'q')
    time.sleep(2)  # Adjust the sleep duration based on your system's speed
    pyautogui.write('1')
    time.sleep(2)
    pyautogui.press('enter')  # Press 'Enter' to confirm

    


def right_click_on_image(numPages):
    time.sleep(15)
    zoom_to_100_percent()
    for i in range(numPages):
        time.sleep(5)
        # Get screen resolution
        screen_width, screen_height = pyautogui.size()

        # Calculate middle coordinates
        middle_x = screen_width / 2
        middle_y = screen_height / 2

        # Adjust these coordinates based on your screen resolution and Word version
        x, y = middle_x + 50, middle_y + 70

        # time.sleep(5)
        if i == 0:
            # Right-click at the current mouse position
            pyautogui.click(x, y, button='right')
            time.sleep(2)
            pyautogui.press('down')
            pyautogui.write('View Alt Text')
            time.sleep(2)
            pyautogui.press('down')
            pyautogui.press('enter')  # Press 'Enter' to confirm
        else:
            for j in range(2):
                # Right-click at the current mouse position
                pyautogui.click(x, y, button='right')
                time.sleep(2)
                pyautogui.press('down')
                pyautogui.write('View Alt Text')
                time.sleep(2)
                pyautogui.press('down')
                pyautogui.press('enter')  # Press 'Enter' to confirm
        time.sleep(2)
        txt = 'This is Alt Text ' + str(i)
        pyautogui.write(txt)
        time.sleep(2)
        pyautogui.press('escape')  # Press 'Enter' to confirm
        pyautogui.hotkey('ctrl', 's')
        time.sleep(3)
        # pyautogui.press('pagedown')  
        pyautogui.hotkey('ctrl', 'pagedown')  # Press Ctrl + Page Down to go to the next page

    os.system("taskkill /f /im winword.exe")

def save_as_pdf(word_file_path, pdf_output_path):
    # Create a new Word application
    word_app = win32com.client.Dispatch("Word.Application")

    # Open the Word document
    doc = word_app.Documents.Open(word_file_path)

    # Save as PDF
    doc.SaveAs2(pdf_output_path, FileFormat=17)

    # Close the Word document
    doc.Close()

    # Quit the Word application
    word_app.Quit()

def process_all_files(input_folder, output_folder):
    for file_name in os.listdir(input_folder):
        print(file_name)
        if file_name.endswith(".docx") and not file_name.startswith("~$"):
            word_document_path = os.path.join(input_folder, file_name)
            pdf_output_path = os.path.join(output_folder, f"{os.path.splitext(file_name)[0]}.pdf")

            numPages = get_number_of_pages(word_document_path)

            open_word_document(word_document_path)
            right_click_on_image(numPages)
            save_as_pdf(word_document_path, pdf_output_path)

if __name__ == "__main__":
    input_folder = "C:/Users/DHANUNJAY/Desktop/Maps/Input"
    output_folder = "C:/Users/DHANUNJAY/Desktop/Maps/Output"
    process_all_files(input_folder, output_folder)
