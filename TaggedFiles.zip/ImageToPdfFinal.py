# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 04:01:39 2024

@author: DHANUNJAY
"""


'''import img2pdf
import os
from PIL import Image, ImageFilter, ImageEnhance

def convert_images_to_pdf(image_files, output_pdf_path):
    with open(output_pdf_path, "wb") as pdf_file:
        pdf_file.write(img2pdf.convert(image_files))


def enhance_image_quality(image_path, output_pdf_path):
    image = Image.open(image_path)
    
    # Enhance the image quality
    enhancer = ImageEnhance.Sharpness(image)
    enhanced_image = enhancer.enhance(2.0)  # Adjust the factor as needed

    # Additional filters for enhancement
    enhanced_image = enhanced_image.filter(ImageFilter.SHARPEN)
    enhanced_image = enhanced_image.filter(ImageFilter.SMOOTH_MORE)
    
    # Convert the image to RGB mode if it's not already
    if enhanced_image.mode != 'RGB':
        enhanced_image = enhanced_image.convert('RGB')
    
    # Save the enhanced image to a temporary file
    temp_image_path = "temp_image.jpg"
    enhanced_image.save(temp_image_path, quality=2000)  # Adjust the quality parameter as needed
    
    # Convert the temporary image to PDF
    convert_images_to_pdf([temp_image_path], output_pdf_path)
    
    # Remove the temporary image file
    os.remove(temp_image_path)



# Example usage
input_img = "C:/Users/DHANUNJAY/Desktop/Maps/ReportImages/"
output_pdf = "C:/Users/DHANUNJAY/Desktop/Maps/TabFiles/"

for filename in os.listdir(input_img):
    pdfInputFile = os.path.join(input_img, filename)
    pdfOutputFile = os.path.join(output_pdf, os.path.splitext(filename)[0] + '.pdf')
    
    enhance_image_quality(pdfInputFile, pdfOutputFile)
    print(f"Enhanced and saved: {pdfOutputFile}")'''
    
    
    
import img2pdf
import os
from PIL import Image, ImageFilter, ImageEnhance

def convert_images_to_pdf(image_files, output_pdf_path):
    with open(output_pdf_path, "wb") as pdf_file:
        pdf_file.write(img2pdf.convert(image_files))

def enhance_image_quality(image_path, output_pdf_path):
    image = Image.open(image_path)
    
    # Enhance the image quality
    enhancer = ImageEnhance.Sharpness(image)
    enhanced_image = enhancer.enhance(1.5)  # Adjust the factor as needed

    # Additional filters for enhancement
    enhanced_image = enhanced_image.filter(ImageFilter.SHARPEN)
    enhanced_image = enhanced_image.filter(ImageFilter.SMOOTH_MORE)
    
    # Save the enhanced image to a temporary file (PNG format for lossless compression)
    temp_image_path = "temp_image.png"
    enhanced_image.save(temp_image_path)
    
    # Convert the temporary image to PDF
    convert_images_to_pdf([temp_image_path], output_pdf_path)
    
    # Remove the temporary image file
    os.remove(temp_image_path)

# Example usage
input_img = "C:/Users/DHANUNJAY/Desktop/Maps/ImageReports/"
output_pdf = "C:/Users/DHANUNJAY/Desktop/Maps/ImgToPdf/"

for filename in os.listdir(input_img):
    pdfInputFile = os.path.join(input_img, filename)
    pdfOutputFile = os.path.join(output_pdf, os.path.splitext(filename)[0] + '.pdf')
    
    enhance_image_quality(pdfInputFile, pdfOutputFile)
    print(f"Enhanced and saved: {pdfOutputFile}")

