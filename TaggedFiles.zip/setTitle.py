# -*- coding: utf-8 -*-
"""
Created on Mon Jan 29 20:22:58 2024

@author: DHANUNJAY
"""

'''import PyPDF2
import os

def set_pdf_title(input_path, output_path, title):
    with open(input_path, 'rb') as input_file, open(output_path, 'wb') as output_file:
        pdf_reader = PyPDF2.PdfReader(input_file)
        pdf_writer = PyPDF2.PdfWriter()

        # Copy the pages and metadata from the original PDF
        for page_num in range(len(pdf_reader.pages)):
            pdf_writer.add_page(pdf_reader.pages[page_num])

        # Set the title in the document information
        pdf_writer.add_metadata({'/Title': title})

        # Write the modified PDF to the output file
        pdf_writer.write(output_file)

# Example usage
input_pdf = "C:/Users/DHANUNJAY/Desktop/Maps/ImgToPdf/"
output_pdf = "C:/Users/DHANUNJAY/Desktop/Maps/TabFiles/"

for filename in os.listdir(input_pdf):
    pdfInputFile = input_pdf + filename
    pdfOutputFile = output_pdf + filename.split('.')[0] + 'WithTitle.pdf'
    set_pdf_title(pdfInputFile, pdfOutputFile, filename)

    
    print(filename)
    

document_title = 'some_title'

set_pdf_title(input_pdf, output_pdf, document_title)'''



import PyPDF2
import os

def set_pdf_title(input_path, output_path, title):
    with open(input_path, 'rb') as input_file, open(output_path, 'wb') as output_file:
        pdf_reader = PyPDF2.PdfReader(input_file)
        pdf_writer = PyPDF2.PdfWriter()

        # Copy the pages and metadata from the original PDF
        for page_num in range(len(pdf_reader.pages)):
            pdf_writer.add_page(pdf_reader.pages[page_num])

        # Set the title in the document information
        pdf_writer.add_metadata({'/Title': title})

        # Write the modified PDF to the output file
        pdf_writer.write(output_file)

# Input and output directories
input_pdf_dir = "C:/Users/DHANUNJAY/Desktop/Maps/ImgToPdf/"
output_pdf_dir = "C:/Users/DHANUNJAY/Desktop/Maps/TabFiles/"

# Example usage
for filename in os.listdir(input_pdf_dir):
    input_pdf_path = os.path.join(input_pdf_dir, filename)
    output_pdf_path = os.path.join(output_pdf_dir, f"{os.path.splitext(filename)[0]}WithTitle.pdf")
    document_title = os.path.splitext(filename)[0]  # Use filename without extension as the document title
    set_pdf_title(input_pdf_path, output_pdf_path, document_title)
    print(f"Title set for {filename}")

# Specify a global document title (if needed)
global_document_title = 'some_title'
# set_pdf_title(input_pdf, output_pdf, global_document_title)

