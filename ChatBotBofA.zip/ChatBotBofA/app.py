from flask import Flask, render_template, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity



# from transformers import AutoModelForCausalLM, AutoTokenizer
# import torch


# tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-medium")
# model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")


app = Flask(__name__)

@app.route("/")
def index():
    return render_template('chat.html')


@app.route("/get", methods=["GET", "POST"])
def chat():
    msg = request.form["msg"]
    input = msg
    return get_Chat_response(input)


def get_Chat_response(text):
    df = pd.read_excel('D:/MyLearning/Chatbot/Dataset.xlsx')
    tfidf_vectorizer = TfidfVectorizer()

        # Fit and transform the DataFrame column
    tfidf_matrix = tfidf_vectorizer.fit_transform(df['Question'])


    # Let's chat for 5 lines
    for step in range(5):
        user_query_tfidf = tfidf_vectorizer.transform([text])

        # Calculate cosine similarity between user query and all column values
        cosine_similarities = cosine_similarity(user_query_tfidf, tfidf_matrix).flatten()

        # Find index of text with highest cosine similarity
        most_similar_index = cosine_similarities.argmax()

        most_similar_text = df.loc[most_similar_index, 'Answer']

        
        return most_similar_text
        '''# encode the new user input, add the eos_token and return a tensor in Pytorch
        new_user_input_ids = tokenizer.encode(str(text) + tokenizer.eos_token, return_tensors='pt')

        # append the new user input tokens to the chat history
        bot_input_ids = torch.cat([chat_history_ids, new_user_input_ids], dim=-1) if step > 0 else new_user_input_ids

        # generated a response while limiting the total chat history to 1000 tokens, 
        chat_history_ids = model.generate(bot_input_ids, max_length=1000, pad_token_id=tokenizer.eos_token_id)

        # pretty print last ouput tokens from bot
        return tokenizer.decode(chat_history_ids[:, bot_input_ids.shape[-1]:][0], skip_special_tokens=True)'''
    


if __name__ == '__main__':
    app.run()
