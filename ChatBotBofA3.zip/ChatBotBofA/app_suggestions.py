from flask import Flask, render_template, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from itertools import chain


app = Flask(__name__)

# Load suggestions from the Excel file
excel_file_path = r'D:\MyLearning\Chatbot\Dataset.xlsx'  # Update with your file path
df = pd.read_excel(excel_file_path)
possibleQuestions = df['Question'].tolist()

@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/get-suggestions', methods=['POST'])
def get_suggestions():
    user_input = request.form['input'].lower()
    suggestions = [question for question in possibleQuestions if user_input in question.lower()]
    return jsonify(suggestions=suggestions)

@app.route("/calculate", methods=["POST"])
def calculate_total_amount():
    try:
        principal = float(request.form["principal"])
        interest_rate = float(request.form["interestRate"])
        tenure = int(request.form["tenure"])

        # Calculate the total amount (modify the calculation logic as needed)
        total_amount = principal + ((principal * interest_rate * tenure) / 100)

        response = {"totalAmount": total_amount}
        return jsonify(response)
    except Exception as e:
        response = {"error": "Invalid input. Please check the values and try again."}
        return jsonify(response), 400  # Return a 400 Bad Request status for errors

@app.route("/get", methods=["GET", "POST"])
def chat():
    msg = request.form["msg"]
    input = msg
    return get_Chat_response(input)

def get_Chat_response(text):
    df = pd.read_excel('D:/MyLearning/Chatbot/Dataset.xlsx')
    tfidf_vectorizer = TfidfVectorizer()

    # Fit and transform the DataFrame column
    tfidf_matrix = tfidf_vectorizer.fit_transform(df['Question'] + ' ' + df['Answer'])

    # Let's chat for 5 lines
    for step in range(5):
        user_query_tfidf = tfidf_vectorizer.transform([text])

        # Calculate cosine similarity between user query and all column values
        cosine_similarities = cosine_similarity(user_query_tfidf, tfidf_matrix).flatten()

        if max(cosine_similarities) > 0.6:
            most_similar_index = cosine_similarities.argmax()
            most_similar_text = df.loc[most_similar_index, 'Answer']
            return str(most_similar_text)
        elif max(cosine_similarities) > 0.30 and max(cosine_similarities) < 0.6:
            ind = list(chain.from_iterable(np.argwhere(cosine_similarities > 0.0)))
            suggestionPrefix = ['Based on your query I can answer below questions. Please choose one!']
            suggestedQuestions = list(df.loc[ind, 'Question'])
            suggestedQuestions = suggestionPrefix + suggestedQuestions
            return jsonify(suggestedQuestions)
        else:
            dfDict = {'NewQuestions':[text]}
            df2 = pd.DataFrame(dfDict)
            dfNewQtn = pd.read_excel('D:/MyLearning/Chatbot/NewQuestions.xlsx')
            dfNewQtn = pd.concat([dfNewQtn, df2], ignore_index = True)
            dfNewQtn = dfNewQtn.loc[:,~dfNewQtn.columns.str.startswith('Unnamed')]

            dfNewQtn.to_excel('D:/MyLearning/Chatbot/NewQuestions.xlsx')
            most_similar_text = "Sorry I couldn't answer your question. Please try asking with different words or send an email to askMe@bofa.com"
            return str(most_similar_text)

if __name__ == '__main__':
    app.run()
