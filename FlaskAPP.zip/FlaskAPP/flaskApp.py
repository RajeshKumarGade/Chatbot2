# -*- coding: utf-8 -*-
"""
Created on Fri Oct 27 01:13:28 2023

@author: DHANUNJAY
"""

from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import os

app = Flask(__name__)

csv_filepath = 'D:/PythonPrograms/FlaskAPP/StudentData.csv'
df = pd.read_csv(csv_filepath)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/read_data', methods=['GET'])
def read_data():
    csv_filepath = 'D:/PythonPrograms/FlaskAPP/StudentData.csv'
    df = pd.read_csv(csv_filepath)

    html_table = df.to_html(classes='table table-bordered', index=False, escape=False)
    return html_table

@app.route('/insert_data', methods=['GET', 'POST'])
def insert_data():
    if request.method == 'POST':
        new_data = {
            'StudentID': request.form['StudentID'],
            'StudentName': request.form['StudentName'],
            'Class': request.form['Class']
        }
        csv_filepath = 'D:/PythonPrograms/FlaskAPP/StudentData.csv'
        df = pd.read_csv(csv_filepath)

        df = df.append(new_data, ignore_index=True)
        df.to_csv(csv_filepath, index=False)
    return render_template('insert_data.html')

@app.route('/update_data', methods=['GET', 'POST'])
def update_data():
    csv_filepath = 'D:/PythonPrograms/FlaskAPP/StudentData.csv'
    df = pd.read_csv(csv_filepath)

    if request.method == 'POST':
        student_id = int(request.form['StudentID'])
        df.loc[df['StudentID'] == student_id, 'StudentName'] = request.form['StudentName']
        df.loc[df['StudentID'] == student_id, 'Class'] = request.form['Class']
        df.to_csv(csv_filepath, index=False)
    return render_template('update_data.html')

@app.route('/delete_data', methods=['GET', 'POST'])
def delete_data():
    csv_filepath = 'D:/PythonPrograms/FlaskAPP/StudentData.csv'
    df = pd.read_csv(csv_filepath)

    if request.method == 'POST':
        student_id = int(request.form['StudentID'])
        df.drop(df[df['StudentID'] == student_id].index, inplace=True)
        df.to_csv(csv_filepath, index=False)
    return render_template('delete_data.html')

if __name__ == '__main__':
    app.run(debug=True)
